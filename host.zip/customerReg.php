<!DOCTYPE HTML>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="css/style.css">
</
	<title>Customer Registration</title>
</head>
<body>
<div class="body">
</div>
<div class="grad"></div>
		<div class="header">
			<div>Customer <br>
            <span>Registration</span></div>
		</div>
		<br>
		<div class="login">
           <form action="insertCustomer.php" method="post">
<br/>
        		<input id="username" name="uname" placeholder="username" type="text">
				<input id="passss" name="pss" placeholder="**********" type="password"><br/>
                <input id="email" name="email" placeholder="email" type="text"><br/>
				<input id="address" name="address" placeholder="address" type="text"><br/>
                <input id="telephone" name="telephone" placeholder="telephone" type="text"><br/>
				<input name="submit" type="submit" value="Register">
                               
				</form>      
</body>



</html>
