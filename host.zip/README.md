# RapidDeliveryweb1.4
Courier management system
V 1.4 with multi user login

DB fully connected to the "RapidDeliverynew".
Other SQL files are only for testing purposes. No need them to run the system.
